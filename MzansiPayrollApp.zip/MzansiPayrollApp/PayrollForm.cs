using System;
using System.Windows.Forms;

namespace MzansiPayrollApp
{
    public partial class PayrollForm : Form
    {
        const decimal HOURLY_RATE = 950m;
        const int MAX_DEPENDENTS = 10;

        public PayrollForm() { InitializeComponent(); nudDependents.Maximum = 15; }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return; // stops if validation fails
            CalculatePay();


         }
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Contractor name cannot be empty");
                txtName.Focus(); return false;
            }

            if (!decimal.TryParse(nudDependents.Text, out decimal depCount) || depCount < 0 || depCount > 10)
            {
                MessageBox.Show("Dependents must be 0 to 10");
                nudDependents.Focus(); return false;
            }

            return true; // <- ADD THIS LINE
        }



        private void CalculatePay()
        {
            decimal hours = decimal.Parse(txtHours.Text);
            int dependents = (int)nudDependents.Value;

            decimal gross = hours * HOURLY_RATE;
            decimal uif = gross * 0.01m; // 1%
            decimal membership = gross * 0.13m; // 13%

            // PAYE = (Gross - (Gross * 0.0575 * Dependents)) * 25%
            decimal payeBase = gross - (gross * 0.0575m * dependents);
            if (payeBase < 0) payeBase = 0;
            decimal paye = payeBase * 0.25m;

            decimal totalDed = uif + paye + membership;
            decimal net = gross - totalDed;

            lblGrossPay.Text = $"R {gross:F2}";
            lblUIF.Text = $"R {uif:F2}";
            lblPAYE.Text = $"R {paye:F2}";
            lblMembership.Text = $"R {membership:F2}";
            lblTotalDed.Text = $"R {totalDed:F2}";
            lblNetPay.Text = $"R {net:F2}";
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtHours.Text = "";
            nudDependents.Value = 0;
            lblGrossPay.Text = lblUIF.Text = lblPAYE.Text =
            lblMembership.Text = lblTotalDed.Text = lblNetPay.Text = "R 0.00";
        }

        private void btnExit_Click(object sender, EventArgs e) => this.Close();
    }
}
