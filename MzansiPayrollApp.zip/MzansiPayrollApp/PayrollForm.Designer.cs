﻿namespace MzansiPayrollApp
{
    partial class PayrollForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblHours = new System.Windows.Forms.Label();
            this.txtHours = new System.Windows.Forms.TextBox();
            this.lblDependents = new System.Windows.Forms.Label();
            this.nudDependents = new System.Windows.Forms.NumericUpDown();

            this.lblGrossPayText = new System.Windows.Forms.Label();
            this.lblUIFText = new System.Windows.Forms.Label();
            this.lblPAYEText = new System.Windows.Forms.Label();
            this.lblMembershipText = new System.Windows.Forms.Label();
            this.lblTotalDedText = new System.Windows.Forms.Label();
            this.lblNetPayText = new System.Windows.Forms.Label();

            this.lblGrossPay = new System.Windows.Forms.Label();
            this.lblUIF = new System.Windows.Forms.Label();
            this.lblPAYE = new System.Windows.Forms.Label();
            this.lblMembership = new System.Windows.Forms.Label();
            this.lblTotalDed = new System.Windows.Forms.Label();
            this.lblNetPay = new System.Windows.Forms.Label();

            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.nudDependents)).BeginInit();
            this.SuspendLayout();

            // Input Controls
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(20, 20);
            this.lblName.Text = "Contractor Name:";

            this.txtName.Location = new System.Drawing.Point(160, 18);
            this.txtName.Size = new System.Drawing.Size(150, 23);
            this.txtName.Name = "txtName";

            this.lblHours.AutoSize = true;
            this.lblHours.Location = new System.Drawing.Point(20, 55);
            this.lblHours.Text = "Hours Worked:";

            this.txtHours.Location = new System.Drawing.Point(160, 53);
            this.txtHours.Size = new System.Drawing.Size(100, 23);
            this.txtHours.Name = "txtHours";

            this.lblDependents.AutoSize = true;
            this.lblDependents.Location = new System.Drawing.Point(20, 90);
            this.lblDependents.Text = "Dependents:";

            this.nudDependents.Location = new System.Drawing.Point(160, 88);
            this.nudDependents.Size = new System.Drawing.Size(100, 23);
            this.nudDependents.Name = "nudDependents";
            this.nudDependents.Maximum = 10;

            // Output Labels - Description
            int y = 130;
            this.lblGrossPayText.AutoSize = true;
            this.lblGrossPayText.Location = new System.Drawing.Point(20, y);
            this.lblGrossPayText.Text = "Gross Pay:";

            y += 25;
            this.lblUIFText.AutoSize = true;
            this.lblUIFText.Location = new System.Drawing.Point(20, y);
            this.lblUIFText.Text = "UIF 1%:";

            y += 25;
            this.lblPAYEText.AutoSize = true;
            this.lblPAYEText.Location = new System.Drawing.Point(20, y);
            this.lblPAYEText.Text = "PAYE:";

            y += 25;
            this.lblMembershipText.AutoSize = true;
            this.lblMembershipText.Location = new System.Drawing.Point(20, y);
            this.lblMembershipText.Text = "Membership 13%:";

            y += 25;
            this.lblTotalDedText.AutoSize = true;
            this.lblTotalDedText.Location = new System.Drawing.Point(20, y);
            this.lblTotalDedText.Text = "Total Deductions:";

            y += 25;
            this.lblNetPayText.AutoSize = true;
            this.lblNetPayText.Location = new System.Drawing.Point(20, y);
            this.lblNetPayText.Text = "Net Pay:";

            y += 35;

            // Output Labels - Values
            int y2 = 130;
            this.lblGrossPay.AutoSize = true;
            this.lblGrossPay.Location = new System.Drawing.Point(180, y2);
            this.lblGrossPay.Text = "R 0.00";
            this.lblGrossPay.Name = "lblGrossPay";

            y2 += 25;
            this.lblUIF.AutoSize = true;
            this.lblUIF.Location = new System.Drawing.Point(180, y2);
            this.lblUIF.Text = "R 0.00";
            this.lblUIF.Name = "lblUIF";

            y2 += 25;
            this.lblPAYE.AutoSize = true;
            this.lblPAYE.Location = new System.Drawing.Point(180, y2);
            this.lblPAYE.Text = "R 0.00";
            this.lblPAYE.Name = "lblPAYE";

            y2 += 25;
            this.lblMembership.AutoSize = true;
            this.lblMembership.Location = new System.Drawing.Point(180, y2);
            this.lblMembership.Text = "R 0.00";
            this.lblMembership.Name = "lblMembership";

            y2 += 25;
            this.lblTotalDed.AutoSize = true;
            this.lblTotalDed.Location = new System.Drawing.Point(180, y2);
            this.lblTotalDed.Text = "R 0.00";
            this.lblTotalDed.Name = "lblTotalDed";

            y2 += 25;
            this.lblNetPay.AutoSize = true;
            this.lblNetPay.Location = new System.Drawing.Point(180, y2);
            this.lblNetPay.Text = "R 0.00";
            this.lblNetPay.Name = "lblNetPay";

            // Buttons
            this.btnCalculate.Location = new System.Drawing.Point(20, y2 + 15);
            this.btnCalculate.Size = new System.Drawing.Size(80, 30);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);

            this.btnReset.Location = new System.Drawing.Point(110, y2 + 15);
            this.btnReset.Size = new System.Drawing.Size(80, 30);
            this.btnReset.Name = "btnReset";
            this.btnReset.Text = "Reset";
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);

            this.btnExit.Location = new System.Drawing.Point(200, y2 + 15);
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.Name = "btnExit";
            this.btnExit.Text = "Exit";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, y2 + 65);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblHours);
            this.Controls.Add(this.txtHours);
            this.Controls.Add(this.lblDependents);
            this.Controls.Add(this.nudDependents);
            this.Controls.Add(this.lblGrossPayText);
            this.Controls.Add(this.lblUIFText);
            this.Controls.Add(this.lblPAYEText);
            this.Controls.Add(this.lblMembershipText);
            this.Controls.Add(this.lblTotalDedText);
            this.Controls.Add(this.lblNetPayText);
            this.Controls.Add(this.lblGrossPay);
            this.Controls.Add(this.lblUIF);
            this.Controls.Add(this.lblPAYE);
            this.Controls.Add(this.lblMembership);
            this.Controls.Add(this.lblTotalDed);
            this.Controls.Add(this.lblNetPay);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Name = "PayrollForm";
            this.Text = "Mzansi Tech Contractors Payroll";
            ((System.ComponentModel.ISupportInitialize)(this.nudDependents)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Label lblName, lblHours, lblDependents;
        private System.Windows.Forms.TextBox txtName, txtHours;
        private System.Windows.Forms.NumericUpDown nudDependents;
        private System.Windows.Forms.Label lblGrossPayText, lblUIFText, lblPAYEText, lblMembershipText, lblTotalDedText, lblNetPayText;
        private System.Windows.Forms.Label lblGrossPay, lblUIF, lblPAYE, lblMembership, lblTotalDed, lblNetPay;
        private System.Windows.Forms.Button btnCalculate, btnReset, btnExit;
    }
}
